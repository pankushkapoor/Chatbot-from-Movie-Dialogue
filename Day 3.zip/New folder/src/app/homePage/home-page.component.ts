import { Component, OnInit } from '@angular/core';
import { User } from '../users/user/userInterface';
import { Profile } from '../profiles/profile/profileInterface';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CapBookServicesService } from '../services/cap-book-services.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {

  pageTitle="Welcome!";
  error: string;
  user: User = {
    userName: "",
    password: "",
    profile: {
              name: "",
              gender: "",
              phoneNo: "",
              dateOfBirth: "", 
              bio: "",
              emailId: ""
            }
  }
  constructor(private route:ActivatedRoute,private router:Router, private httpClient: HttpClient, private capBookService: CapBookServicesService) { }

  ngOnInit() {
    const _user=this.route.snapshot.paramMap.get('userName');
    //const productId= +id;
    this.capBookService.getUserDetails(_user).subscribe(
      user=>{
      this.user=user;
    },
    errorMessage=>{
      this.error=errorMessage;
    })    

    const _user1=this.route.snapshot.paramMap.get('emailId');
    //const productId= +id;
    this.capBookService.getProfileDetails(_user1).subscribe(
      profile1=>{
      this.user.profile=profile1;
    },
    errorMessage=>{
      this.error=errorMessage;
    }) 
  }
  public viewProfile():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/profile',{"userName":this.user.userName}])
  }
  public goToHome():void{
    if(this.user.profile.name!=null)
    this.router.navigate(['/homePage',{"emailId":this.user.profile.emailId}])
  }

}
